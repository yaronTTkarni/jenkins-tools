optional_arguments_name = ["command=",
                           "jenkins_ip=",
                           "jenkins_port=",
                           "jenkins_user=",
                           "jenkins_password=",
                           "git_user=",
                           "git_password=",
                           "parent_branch=",
                           "new_release_name=",
                           "version_major=", "version_minor=", "version_patch=",
                           "version_prefix_to_delete=",
                           "version_prefix_to_archive=",
                           "specific_pipelines="]

HTTP_S_S = 'http://%s:%s'
